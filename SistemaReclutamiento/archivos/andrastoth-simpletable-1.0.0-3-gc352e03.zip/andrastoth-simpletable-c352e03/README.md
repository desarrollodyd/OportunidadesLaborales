simpletable jQuery-plugin
=========================

jQuery plugin for practical HTML table handling

http://andrastoth.github.com/simpletable/


